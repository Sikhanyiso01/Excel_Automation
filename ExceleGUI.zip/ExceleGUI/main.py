import tkinter as tk
from tkinter import  ttk
import openpyxl
wb = openpyxl.load_workbook("people.xlsx")
def load_data():

    sheet = wb.active
    listValues =  list(sheet.values)
    print(listValues)
    for col_names in listValues[0]:
        treeView.heading(col_names, text=col_names)
    for val_tuple in listValues[1:]:
        treeView.insert('', tk.END,values=val_tuple)

def insert_data():
    name = nameEntry.get()
    age = int(ageSel.get())
    employVar = "Employed" if a.get() else "Unemployed"
    subscription = subscribedDrop.get()
    sheet = wb.active
    row_Val = [name, age, subscription, employVar]
    sheet.append(row_Val)
    wb.save("people.xlsx")

    treeView.insert('', tk.END, values=row_Val)

    nameEntry.delete(0, "end")
    nameEntry.insert(0, "Name")
    ageSel.delete(0, "end")
    ageSel.insert(0, "Age")
    subscribedDrop.set(combo_list[0])
    check_Button.state(["!selected"])

def toggle_mode():
    if modeSwitch.instate(["selected"]):

        style.theme_use("forest-light")
    else:

        style.theme_use("forest-dark")
def search_data():
    query = searchEntry.get().lower()
    for row in treeView.get_children():
        treeView.delete(row)

    sheet = wb.active
    for row in sheet.iter_rows(values_only=True):
        if query in row[0].lower():
            treeView.insert("", tk.END, values=row)

root =  tk.Tk()
style =  ttk.Style(root)

root.tk.call("source", "forest-dark.tcl")
root.tk.call("source", "forest-light.tcl")
style.theme_use("forest-dark")
combo_list = ["Subscribed", "Unsubscribed", "Other"]

frame = ttk.Frame(root)
frame.pack()

widget_Frame = ttk.LabelFrame(frame, text="Insert Row")
widget_Frame.grid(column=0, row=0, pady=10, padx=20)

nameEntry = ttk.Entry(widget_Frame)
nameEntry.insert(0, "Name")
nameEntry.grid(column=0, row=0,padx=5, pady=(0 ,5),  sticky="ew")
nameEntry.bind("<FocusIn>", lambda e: nameEntry.delete('0', 'end'))

ageSel = ttk.Spinbox(widget_Frame, from_=18, to=100)
ageSel.insert(0, "Age")
ageSel.bind("<FocusIn>", lambda e: ageSel.delete("0", "end"))
ageSel.grid(column=0, row=1, padx=5, pady=5, sticky="ew")

subscribedDrop = ttk.Combobox(widget_Frame, values=combo_list)
subscribedDrop.current(0)
subscribedDrop.grid(column=0, row=2, padx=5, pady=5, sticky="ew")

a = tk.BooleanVar()
check_Button = ttk.Checkbutton(widget_Frame, text="Employed", variable=a)
check_Button.grid(column=0, row=3, padx=5, pady=5, sticky="nsew")

addingBtn = ttk.Button(widget_Frame, text="Insert", command=insert_data)
addingBtn.grid(column=0, row=4, sticky="nsew")

separator = ttk.Separator(widget_Frame)
separator.grid(row=5, column=0, pady=10, padx=(10, 20), sticky="ew")

modeSwitch = ttk.Checkbutton(widget_Frame, text="Mode", style="Switch.TCheckbutton", command=toggle_mode)
modeSwitch.grid(row=6, column=0, padx=5, pady=10, sticky="nsew")

treeFrame = ttk.Frame(frame)
treeFrame.grid(column=1, row=0, pady=10)
treeScroll = ttk.Scrollbar(treeFrame)
treeScroll.pack(side="right", fill="y")

cols = ("Name", "Age", "Subscription", "Employment")
treeView =  ttk.Treeview(treeFrame, show="headings",
                         yscrollcommand=treeScroll.set, columns=cols, height=13)
treeView.column("Name", width=100)
treeView.column("Age", width=50)
treeView.column("Subscription", width=100)
treeView.column("Employment", width=100)
treeView.pack()
treeScroll.configure(command=treeView.yview)
#Added a feature to search  using a name.
searchEntry = ttk.Entry(frame)
searchEntry.insert(0, "Search Name")
searchEntry.bind("<FocusIn>", lambda e: searchEntry.delete(0, "end"))
searchEntry.grid(column=0, row=6, pady=5, padx=10, sticky="ew")

searchBtn = ttk.Button(frame, text="Search", command=search_data)
searchBtn.grid(column=1, row=6, pady=5, padx=10, sticky="ew")


load_data()
root.mainloop()

